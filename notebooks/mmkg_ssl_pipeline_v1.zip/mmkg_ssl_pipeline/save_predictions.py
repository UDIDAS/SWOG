"""
save_predictions.py
===================
Save your SSL model's predicted segmentation as a NIfTI mask the MMKG app can
render in 3D.

You already produce a predicted label array during inference (that's how you got
the voxel counts). This helper SAVES that array correctly:

  * labels 0/1/2 (uint8)
  * SAME shape + affine as the source CT  (so the 3D lines up)
  * named pancreas_001 / LiTs-000          (so it matches our cases)

Typical use (see example_inference_integration.py for a full loop):

    from save_predictions import save_prediction
    save_prediction(pred_mask, ct_path, "pancreas_001", "predictions/pancreas",
                    dataset="pancreas")
"""
import os
import numpy as np
import nibabel as nib

# Label meaning per dataset — must match EXACTLY.
LABELS = {
    "pancreas": {0: "background", 1: "Pancreas", 2: "Tumor"},
    "lits":     {0: "background", 1: "Liver",    2: "Tumor"},
}


def save_prediction(pred_array, reference_ct_path, case_id, out_dir, dataset):
    """
    Parameters
    ----------
    pred_array : 3D numpy array of integer labels (0/1/2), SAME shape as the CT
                 it was predicted from. (If your model outputs probabilities,
                 take argmax over the class axis first.)
    reference_ct_path : path to the source CT .nii.gz. We copy its affine/header
                        so the saved mask lines up with the scan in 3D.
    case_id    : 'pancreas_001' or 'LiTs-000' (zero-padded 3 digits).
    out_dir    : folder to write into (created if missing).
    dataset    : 'pancreas' or 'lits'.

    Returns
    -------
    out_path : path to the saved .nii.gz

    Raises
    ------
    ValueError with a clear message if any of the 3 rules is violated.
    """
    if dataset not in LABELS:
        raise ValueError(f"dataset must be one of {list(LABELS)}, got {dataset!r}")

    ct = nib.load(reference_ct_path)
    pred = np.asarray(pred_array)

    # Rule 2: shape must match the CT (no resampling drift)
    if tuple(pred.shape) != tuple(ct.shape):
        raise ValueError(
            f"[{case_id}] prediction shape {pred.shape} != CT shape {ct.shape}. "
            "Predict at the CT's native grid — do NOT resample to 1mm / 128^3 / etc."
        )

    # Rule 1: labels must be a subset of {0,1,2}
    present = set(int(v) for v in np.unique(pred))
    allowed = set(LABELS[dataset])
    extra = present - allowed
    if extra:
        raise ValueError(
            f"[{case_id}] found labels {sorted(extra)} but only {sorted(allowed)} "
            f"are allowed {LABELS[dataset]}. Run argmax / remap to 0/1/2 first."
        )

    # Rule 3: write with the CT's affine so the 3D lines up
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"{case_id}.nii.gz")
    img = nib.Nifti1Image(pred.astype(np.uint8), ct.affine, ct.header)
    img.set_data_dtype(np.uint8)
    nib.save(img, out_path)

    # Friendly confirmation
    counts = {LABELS[dataset][k]: int((pred == k).sum()) for k in allowed if k != 0}
    print(f"[OK] {case_id}: saved -> {out_path}")
    print(f"     shape={tuple(pred.shape)}  labels_present={sorted(present)}  voxels={counts}")
    if present <= {0}:
        print(f"     [WARN] {case_id} is EMPTY (background only) — is that expected?")
    return out_path
