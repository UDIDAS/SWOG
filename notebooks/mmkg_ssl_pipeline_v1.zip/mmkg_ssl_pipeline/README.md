# MMKG SSL Pipeline — Hand-off Kit (read me first)

**Goal:** give us your SSL model's **predicted segmentation masks** as `.nii.gz`
files, in a format our app can render in 3D. That's the *only* thing we need
from you. This kit makes that one step easy and gives you a validator so you
know it's correct **before** you send.

> New here? Read **`WHAT_WAS_MISSING.md`** first (2 min) — it explains in plain
> English why the CSV of numbers you sent wasn't enough, and what a "mask" is.

---

## TL;DR (the whole job in 4 steps)

```
1. pip install -r requirements.txt
2. python validate_predictions.py --pred sample_output/predictions/pancreas \
       --ct sample_output/ct --dataset pancreas      # see it print PASS
3. In your inference code, call save_prediction(...)  # see example_inference_integration.py
4. Validate YOUR output, zip the predictions/ folder, send it back.
```

You already create the mask during inference (that's how you got the voxel
counts). You just need to **save it** instead of throwing it away.

---

## What you send back

One `.nii.gz` per case — nothing else required.

```
predictions/
├── pancreas/
│   ├── pancreas_001.nii.gz
│   ├── pancreas_002.nii.gz
│   └── ...
└── lits/
    ├── LiTs-000.nii.gz
    ├── LiTs-001.nii.gz
    └── ...
```

Zip `predictions/` → send. We do the 3D meshing on our side.

---

## The 3 rules (these make or break it)

| # | Rule | Why |
|---|---|---|
| 1 | **Labels are `0` / `1` / `2` only** (integers) | colors + meshes are picked by label id |
| 2 | **Same shape + affine as the source CT** — do **not** resample | otherwise the 3D comes out mirrored/offset |
| 3 | **Filename = `pancreas_001` or `LiTs-000`** (zero-padded 3 digits) | so it matches our cases |

`save_prediction()` enforces all three and gives a clear error if something's off.

### Label meaning

| Dataset | 0 | 1 | 2 |
|---|---|---|---|
| **pancreas** (MSD Task07) | background | Pancreas | Tumor |
| **lits** (LiTS17) | background | Liver | Tumor |

### Naming note (important for LiTS)

Your earlier CSV used `volume-0`. We need `LiTs-000` — same number, zero-padded
3 digits: `volume-0 → LiTs-000`, `volume-42 → LiTs-042`.

---

## Files in this kit

| File | What it's for |
|---|---|
| `README.md` | this file |
| `WHAT_WAS_MISSING.md` | plain-English: why numbers ≠ masks (read first) |
| `requirements.txt` | `pip install -r requirements.txt` |
| `save_predictions.py` | the helper — saves your model output as a correct `.nii.gz` |
| `example_inference_integration.py` | shows exactly where to call `save_prediction()` in your loop |
| `validate_predictions.py` | run before sending — prints PASS / WARN / FAIL |
| `sample_output/` | a tiny **working** example you can validate right now |

---

## Try the sample first (proves your install works)

```bash
pip install -r requirements.txt

python validate_predictions.py \
    --pred sample_output/predictions/pancreas \
    --ct   sample_output/ct \
    --dataset pancreas
```

Expected: `SUMMARY: 1 pass | 0 warn | 0 fail  → READY`.

Open `sample_output/predictions/pancreas/pancreas_001.nii.gz` in ITK-SNAP / 3D
Slicer to see a correctly-formatted mask (background + a "pancreas" blob + a
"tumor" blob). `sample_output/make_sample.py` shows the code that created it.

---

## Common errors (and the fix)

| Error | Fix |
|---|---|
| `prediction shape (...) != CT shape (...)` | predict at the CT's native grid; don't resample to 1mm/128³ |
| `found labels [3, 4, ...]` | `argmax` / remap your output to `0/1/2` before saving |
| `affine != CT affine` | pass the **source CT path** as `reference_ct_path` so we copy its affine |
| name `volume_3` rejected | rename to `LiTs-003` (or `pancreas_003`) |

---

## FAQ

**Do I need to send the CT scans?** No — we already have the public CTs. Just masks.

**Do I need to mesh / make 3D myself?** No. Masks-only. We do the 3D.

**What about Dice / accuracy numbers?** We compute those on our side once we have
your masks (we compare against ground truth). You don't need to.

**My model outputs probabilities, not labels.** Take `argmax` over the class
axis → integer labels `0/1/2`, then save. (See the example file.)

**Confidence maps?** Optional, skip for now.
