"""
example_inference_integration.py
================================
Shows EXACTLY where to call save_prediction() inside your own inference loop.

This file is a template — replace `load_ct` and `your_model_predict` with your
real code. The only line that matters for us is the `save_prediction(...)` call.

Run order for the whole job:
    1. fill in CASES + the two functions below
    2. python example_inference_integration.py
    3. python validate_predictions.py --pred predictions/pancreas --ct <ct_dir> --dataset pancreas
    4. zip predictions/  ->  send back
"""
import numpy as np
from save_predictions import save_prediction


# ---------------------------------------------------------------------------
# 1) REPLACE these two with your real inference code
# ---------------------------------------------------------------------------
def load_ct(ct_path):
    """Load a CT volume as a numpy array."""
    import nibabel as nib
    return nib.load(ct_path).get_fdata()


def your_model_predict(ct_array):
    """
    Your SSL model. Must return a 3D integer array (labels 0/1/2) with the SAME
    shape as `ct_array`.

    If your model outputs class probabilities of shape (C, X, Y, Z) or
    (X, Y, Z, C), reduce to labels with argmax over the class axis, e.g.:
        logits = model(ct_tensor)          # (C, X, Y, Z)
        pred   = logits.argmax(axis=0)     # (X, Y, Z)  -> values in 0..C-1
    """
    raise NotImplementedError("Plug your SSL model here.")


# ---------------------------------------------------------------------------
# 2) One (case_id, ct_path) per case. case_id MUST be pancreas_NNN or LiTs-NNN.
# ---------------------------------------------------------------------------
DATASET = "pancreas"                       # or "lits"
OUT_DIR = "predictions/pancreas"           # or "predictions/lits"
CASES = [
    ("pancreas_001", r"/path/to/Task07_Pancreas/imagesTr/pancreas_001_0000.nii.gz"),
    ("pancreas_002", r"/path/to/Task07_Pancreas/imagesTr/pancreas_002_0000.nii.gz"),
    # ... add the rest
]


# ---------------------------------------------------------------------------
# 3) The loop — you should not need to change anything below this line
# ---------------------------------------------------------------------------
def main():
    for case_id, ct_path in CASES:
        ct = load_ct(ct_path)
        pred = your_model_predict(ct)              # <- your SSL model
        pred = np.asarray(pred).astype("uint8")    # labels 0/1/2
        save_prediction(pred, ct_path, case_id, OUT_DIR, dataset=DATASET)

    print("\nDone. Now run validate_predictions.py, then zip the 'predictions/' folder.")


if __name__ == "__main__":
    main()
