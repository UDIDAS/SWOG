# What was missing — in plain English

You sent us two CSV files of measurements (tumor volume, diameter, centroid,
t-stage, …). Those are useful — but they can't be shown in 3D. Here's why, and
what we actually need.

---

## The app draws 3D from a *mask*, not from numbers

A **mask** (a.k.a. segmentation) is a 3D grid the **same size as the CT scan**,
where **every single voxel** carries a label:

```
0 = background    1 = organ (pancreas/liver)    2 = tumor
```

That grid is millions of labelled voxels. Our app turns it into a 3D surface
(marching cubes) and shows it. **No mask → no 3D, no slices, no comparison.**

---

## The CSV has voxel *numbers*, not the voxel *map*

Your CSV does mention voxels — but only as **summaries**:

| You sent | What it is |
|---|---|
| `tumor_volume_voxels = 26153` | a **count** — how *many* voxels |
| `tumor_centroid_*_mm` | one **center point** |
| `bbox_*_mm` | the **size of a box** around it |

That's metadata *about* the voxels — not the voxels themselves.

### The analogy

> Knowing a country has an **area of 1,000 km²**, a **capital** at some
> coordinate, and a **bounding box** does **not** let you draw its **borders**.

Same here: a count + a centroid + a box can only make a **featureless blob**.
It cannot reproduce the real **shape** of the pancreas or the tumor. And once the
shape is summarized into a number, it's gone — we can't rebuild it from the CSV
(yours *or* ours).

---

## You already made the mask — you just didn't save it

Your model produces the mask during inference. That's literally how you got
`tumor_volume_voxels` — you counted the voxels in it. Then the mask was
discarded and only the count was kept.

**The fix is one line** — save the array you already have:

```python
import nibabel as nib
nib.save(nib.Nifti1Image(pred_mask.astype("uint8"), ct.affine), "pancreas_001.nii.gz")
```

`save_predictions.py` in this kit does exactly that, plus checks the 3 rules.

---

## One more thing we noticed (please double-check)

The tumor & organ **volumes** in your CSV match the public **ground-truth**
masks *exactly* (in 279 of 281 pancreas cases). A real model's prediction almost
never matches GT voxel-for-voxel — so it looks like the stats were computed on
the **ground-truth** labels, not your model's **prediction**.

Please make sure the array you save is your **model's predicted output**, not the
GT label file. (If it really is the prediction, no worries — the saved masks will
confirm it, because their volumes will differ from GT.)

---

## Summary

| What you sent | What we need |
|---|---|
| Voxel **counts** (numbers about the mask) | The voxel **mask** itself (`.nii.gz`) |
| ~5 numbers per structure | the full labelled 3D grid |
| Enough for tables/charts | Required for 3D + slices + accuracy |
| Possibly computed on **GT** | Must be your **prediction** |

Read **`README.md`** next for the 4-step how-to.
