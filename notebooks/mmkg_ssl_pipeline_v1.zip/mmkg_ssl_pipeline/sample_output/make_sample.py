"""
make_sample.py
==============
Generates the tiny SYNTHETIC example in sample_output/ so you can see the exact
format we expect and run the validator end-to-end.

This is NOT real anatomy — it's a small box with a sphere ("organ", label 1) and
a smaller sphere inside it ("tumor", label 2), on a matching synthetic CT. It
exists purely to demonstrate the file format and to give you a guaranteed-PASS
case to test your install.

Run:  python sample_output/make_sample.py
"""
import os
import numpy as np
import nibabel as nib

HERE = os.path.dirname(os.path.abspath(__file__))
CT_DIR = os.path.join(HERE, "ct")
PRED_DIR = os.path.join(HERE, "predictions", "pancreas")


def main():
    os.makedirs(CT_DIR, exist_ok=True)
    os.makedirs(PRED_DIR, exist_ok=True)

    shape = (64, 64, 48)
    # A realistic-ish voxel spacing + affine (0.7 x 0.7 x 2.5 mm)
    affine = np.diag([0.7, 0.7, 2.5, 1.0]).astype(np.float32)

    zz, yy, xx = np.mgrid[0:shape[0], 0:shape[1], 0:shape[2]]
    cz, cy, cx = (s / 2 for s in shape)

    organ = ((zz - cz) ** 2 + (yy - cy) ** 2 + ((xx - cx) * 1.3) ** 2) < 18 ** 2
    tumor = ((zz - cz - 4) ** 2 + (yy - cy + 3) ** 2 + (xx - cx) ** 2) < 7 ** 2

    mask = np.zeros(shape, dtype=np.uint8)
    mask[organ] = 1
    mask[tumor] = 2   # tumor overwrites organ where they overlap

    # Synthetic CT: soft tissue ~40 HU, organ ~60, tumor ~30, background air -1000
    ct = np.full(shape, -1000.0, dtype=np.float32)
    ct[organ] = 60.0
    ct[tumor] = 30.0
    ct += np.random.default_rng(0).normal(0, 5, shape).astype(np.float32)

    nib.save(nib.Nifti1Image(ct, affine), os.path.join(CT_DIR, "pancreas_001_0000.nii.gz"))
    nib.save(nib.Nifti1Image(mask, affine), os.path.join(PRED_DIR, "pancreas_001.nii.gz"))

    preview = (
        "SAMPLE (synthetic — NOT real anatomy)\n"
        "=====================================\n"
        f"shape        : {shape}\n"
        f"voxel (mm)   : (0.7, 0.7, 2.5)\n"
        f"labels       : 0=background, 1=organ ({int(mask.__eq__(1).sum())} vox), "
        f"2=tumor ({int(mask.__eq__(2).sum())} vox)\n"
        "files        :\n"
        "  ct/pancreas_001_0000.nii.gz            (source CT)\n"
        "  predictions/pancreas/pancreas_001.nii.gz (the mask you would send)\n\n"
        "Validate it:\n"
        "  python validate_predictions.py --pred sample_output/predictions/pancreas "
        "--ct sample_output/ct --dataset pancreas\n"
    )
    with open(os.path.join(HERE, "PREVIEW.txt"), "w") as f:
        f.write(preview)
    print(preview)


if __name__ == "__main__":
    main()
