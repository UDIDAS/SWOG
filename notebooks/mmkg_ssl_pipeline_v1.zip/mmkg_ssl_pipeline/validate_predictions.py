"""
validate_predictions.py
=======================
Run this BEFORE sending. It checks every predicted mask against the 3 rules and
prints PASS / WARN / FAIL. Green = good to ship.

Usage:
    python validate_predictions.py --pred predictions/pancreas \
        --ct /path/to/Task07_Pancreas/imagesTr --dataset pancreas

    python validate_predictions.py --pred predictions/lits \
        --ct /path/to/LiTS/ct --dataset lits

    # No CTs handy? Skip the shape/affine check (still checks labels + naming):
    python validate_predictions.py --pred predictions/pancreas --dataset pancreas --no-ct

Exit codes: 0 = all good (or warnings only), 1 = at least one FAIL, 2 = no files.
"""
import argparse
import glob
import os
import re
import sys

import numpy as np
import nibabel as nib

NAME_RE = {"pancreas": r"^pancreas_\d{3}$", "lits": r"^LiTs-\d{3}$"}
ALLOWED = {"pancreas": {0, 1, 2}, "lits": {0, 1, 2}}


def find_ct(case_id, ct_dir):
    """Match a prediction case_id to its source CT file (best effort)."""
    for cand in (f"{case_id}_0000.nii.gz", f"{case_id}.nii.gz"):
        p = os.path.join(ct_dir, cand)
        if os.path.exists(p):
            return p
    hits = sorted(glob.glob(os.path.join(ct_dir, f"{case_id}*.nii.gz")))
    return hits[0] if hits else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True, help="folder of predicted .nii.gz masks")
    ap.add_argument("--ct", default=None, help="folder of source CT .nii.gz (for shape/affine check)")
    ap.add_argument("--dataset", required=True, choices=["pancreas", "lits"])
    ap.add_argument("--no-ct", action="store_true", help="skip shape/affine check")
    a = ap.parse_args()

    files = sorted(glob.glob(os.path.join(a.pred, "*.nii.gz")))
    if not files:
        print(f"[FAIL] no .nii.gz files found in {a.pred}")
        sys.exit(2)

    n_pass = n_warn = n_fail = 0
    for f in files:
        cid = os.path.basename(f).replace(".nii.gz", "")
        fails, warns = [], []

        # Rule 3: naming
        if not re.match(NAME_RE[a.dataset], cid):
            fails.append(f"name '{cid}' != pattern {NAME_RE[a.dataset]}")

        # load
        try:
            img = nib.load(f)
            arr = np.asanyarray(img.dataobj)
        except Exception as e:
            print(f"[FAIL] {cid}: cannot load ({e})")
            n_fail += 1
            continue

        # Rule 1: labels
        present = set(int(v) for v in np.unique(arr))
        extra = present - ALLOWED[a.dataset]
        if extra:
            fails.append(f"labels {sorted(extra)} not in {sorted(ALLOWED[a.dataset])}")
        if present <= {0}:
            warns.append("empty mask (background only)")

        # Rule 2: shape + affine vs CT
        if not a.no_ct and a.ct:
            ctp = find_ct(cid, a.ct)
            if ctp is None:
                warns.append("no matching CT found (shape/affine not checked)")
            else:
                ct = nib.load(ctp)
                if tuple(img.shape) != tuple(ct.shape):
                    fails.append(f"shape {tuple(img.shape)} != CT {tuple(ct.shape)}")
                elif not np.allclose(img.affine, ct.affine, atol=1e-3):
                    fails.append("affine != CT affine (3D will be misaligned)")
        elif not a.no_ct and not a.ct:
            warns.append("no --ct given (shape/affine not checked)")

        # report line
        if fails:
            n_fail += 1
            print(f"[FAIL] {cid}: " + "; ".join(fails) + (("  | warn: " + "; ".join(warns)) if warns else ""))
        elif warns:
            n_warn += 1
            print(f"[WARN] {cid}: " + "; ".join(warns))
        else:
            n_pass += 1
            print(f"[PASS] {cid}: labels={sorted(present)} shape={tuple(img.shape)}")

    print("-" * 60)
    print(f"SUMMARY: {n_pass} pass | {n_warn} warn | {n_fail} fail")
    if n_fail == 0:
        print("  -> READY. Zip the predictions/ folder and send it back.")
    else:
        print("  -> FIX the FAILs above and re-run.")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
