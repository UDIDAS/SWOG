from .fastloops import *

__doc__ = fastloops.__doc__
if hasattr(fastloops, "__all__"):
    __all__ = fastloops.__all__